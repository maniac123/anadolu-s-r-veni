{\rtf1\ansi\deff0{\fonttbl{\f0\fnil\fcharset162{\*\fname Courier New;}Courier New TUR;}}
{\*\generator Msftedit 5.41.15.1515;}\viewkind4\uc1\pard\lang1055\f0\fs20 function resourceStart84()\par
    kapi=createObject(980,2464.1000976563,-1659.4000244141,15.10000038147,0,0,0)\par
end\par
function cmdHareket84(player,cmd)\par
    moveObject(kapi,7000,2464.1000976563,-1659.4000244141,9.5222)\par
 outputChatBox("HOSGELD\'ddN\'ddZ KAPI A\'c7ILDI",thePlayer)\par
end\par
function cmdEski84(player,cmd)\par
    moveObject(kapi,7000,2464.1000976563,-1659.4000244141,15.10000038147,0,0,0)\par
 outputChatBox("KAPI KAPANDI",thePlayer)\par
end\par
addCommandHandler("a\'e7\'fdlulen",cmdHareket84)\par
addCommandHandler("kapalulen",cmdEski84)\par
addEventHandler("onResourceStart",getResourceRootElement(getThisResource()),resourceStart84)\par
}
 